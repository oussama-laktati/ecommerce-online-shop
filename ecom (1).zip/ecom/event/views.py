from django.shortcuts import render, redirect, get_object_or_404
from . import models
from .forms import SignUpForm
from django.contrib.auth import login, authenticate
from django.contrib.auth import authenticate, login, logout
from .forms import LoginForm
from django.contrib.auth.decorators import login_required

# Create your views here.
def products_main(request):
    top_sales = models.Product.objects.order_by('-sale_count').values_list('sale_count',flat=True).distinct()
    top_products = models.Product.objects.order_by('-sale_count').filter(sale_count__in=top_sales[:6])
    context = {
        'top_products' : top_products
    }
    return render(request,'event/products-main-page.html',context)

def all_products(request):
    product_list = models.Product.objects.all()
    context = {
        'product_list' : product_list
    }
    return render(request,'event/product-list.html',context)

def product_info(request,product_slug):
    selected_product = models.Product.objects.get(slug=product_slug)
    context = {
        'product' : selected_product
    }
    return render(request,'event/product-info.html',context)


def signup(request):
    if request.method == 'POST':
        form = SignUpForm(request.POST)
        if form.is_valid():
            user = form.save()
            user.refresh_from_db()
            user.save()
            raw_password = form.cleaned_data.get('password1')
            user = authenticate(username=user.username, password=raw_password)
            login(request, user)
            return redirect('Home-Page')  # Replace 'home' with your desired redirect URL
    else:
        form = SignUpForm()
    return render(request, 'event/registration/signup.html', {'form': form})

def logout_view(request):
    logout(request)
    return redirect('Home-Page')


def login_view(request):
    if request.method == 'POST':
        form = LoginForm(request.POST)
        if form.is_valid():
            username = form.cleaned_data['username']
            password = form.cleaned_data['password']
            user = authenticate(request, username=username, password=password)
            if user is not None:
                login(request, user)
                # Redirect to the product list page after login
                return redirect('Home-Page')
            else:
                # Invalid login
                return render(request, 'event/registration/login.html', {'form': form, 'error_message': 'Invalid username or password.'})
    else:
        form = LoginForm()
    return render(request, 'event/registration/login.html', {'form': form})


@login_required
def add_to_cart(request, product_id, quantity=1):
    product = get_object_or_404(models.Product, pk=product_id)

    user = request.user

    cart_item, created = models.Cart.objects.get_or_create(user=user, product=product)

    if not created:
        if 'quantity' in request.POST:
            quantity = int(request.POST['quantity'])
        cart_item.quantity = int(quantity)
        cart_item.save()

    return redirect('my_cart')


@login_required
def get_cart(request):
    user = request.user

    cart_items = models.Cart.objects.filter(
        user=request.user).select_related('product')

    products_in_cart = [{"id": item.product.id, "name": item.product.title, "price": item.product.price,
                         "quantity": item.quantity, 'total': item.product.price*item.quantity} for item in cart_items]

    total = sum([i["price"]*i["quantity"] for i in products_in_cart])

    return render(request, 'event/cart.html', {'products': products_in_cart, 'total': total})


@login_required
def delete_from_cart(request, product_id):
    cart_item = get_object_or_404(
        models.Cart, user_id=request.user.id, product_id=product_id)

    if cart_item.user != request.user:
        return redirect('my_cart')

    cart_item.delete()

    return redirect('my_cart')
    