from django.shortcuts import render

def HomePage(request):
    return render(request,'HomePage.html')
def signup(request):
    if request.method == 'POST':
        form = CustomUserCreationForm(request.POST)